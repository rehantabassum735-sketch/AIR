import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { Globe, Cpu, Cog, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const services = [
  {
    icon: Globe,
    title: 'Website Development',
    description:
      'Beautiful, responsive websites that make a lasting impression. From portfolios to e-commerce, we build it all.',
    color: 'from-primary to-primary/80',
  },
  {
    icon: Cpu,
    title: 'Custom Digital Solutions',
    description:
      'Tailored applications and platforms designed specifically for your business needs and workflow.',
    color: 'from-secondary to-secondary/80',
  },
  {
    icon: Cog,
    title: 'Automation & Integrations',
    description:
      'Streamline your operations with smart automations and seamless third-party integrations.',
    color: 'from-accent to-accent/80',
  },
];

export const Services = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="services" className="section-padding bg-background">
      <div className="section-container">
        {/* Header */}
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <span className="inline-block px-4 py-2 mb-4 text-sm font-medium text-primary bg-primary/10 rounded-full">
            Our Services
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-heading font-bold text-foreground mb-6">
            Solutions That <span className="text-secondary">Drive Results</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            We offer a comprehensive range of digital services to help your business
            succeed in the modern digital landscape.
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group relative bg-card rounded-2xl p-8 shadow-card hover:shadow-card-hover transition-all duration-300 hover:-translate-y-2 border border-border"
            >
              {/* Gradient Accent */}
              <div className={`absolute top-0 left-0 right-0 h-1 rounded-t-2xl bg-gradient-to-r ${service.color}`} />

              <div
                className={`w-14 h-14 rounded-xl bg-gradient-to-br ${service.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}
              >
                <service.icon className="h-7 w-7 text-primary-foreground" />
              </div>

              <h3 className="text-xl font-heading font-bold text-foreground mb-4">
                {service.title}
              </h3>

              <p className="text-muted-foreground mb-6 leading-relaxed">
                {service.description}
              </p>

              <Button variant="ghost" className="group/btn p-0 h-auto text-primary hover:text-secondary" asChild>
                <a href="#contact">
                  Contact for Details
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover/btn:translate-x-1" />
                </a>
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
