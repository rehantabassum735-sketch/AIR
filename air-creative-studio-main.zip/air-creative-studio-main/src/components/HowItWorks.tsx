import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { Lightbulb, Code2, Rocket } from 'lucide-react';

const steps = [
  {
    icon: Lightbulb,
    step: '01',
    title: 'Plan',
    description: 'We discuss your vision, goals, and requirements to create a solid roadmap.',
  },
  {
    icon: Code2,
    step: '02',
    title: 'Build',
    description: 'Our team brings your project to life with clean code and stunning design.',
  },
  {
    icon: Rocket,
    step: '03',
    title: 'Deliver',
    description: 'We launch your project and provide support to ensure ongoing success.',
  },
];

export const HowItWorks = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section className="section-padding bg-primary relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-96 h-96 bg-secondary rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-accent rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
      </div>

      <div className="section-container relative z-10">
        {/* Header */}
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <span className="inline-block px-4 py-2 mb-4 text-sm font-medium text-secondary bg-secondary/20 rounded-full">
            Our Process
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-heading font-bold text-primary-foreground mb-6">
            How It Works
          </h2>
          <p className="text-lg text-primary-foreground/70">
            A simple, transparent process that keeps you informed every step of the way.
          </p>
        </motion.div>

        {/* Steps */}
        <div className="grid md:grid-cols-3 gap-8 lg:gap-12">
          {steps.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.15 }}
              className="relative text-center"
            >
              {/* Connector Line */}
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-12 left-[60%] w-[80%] h-0.5 bg-gradient-to-r from-secondary/50 to-transparent" />
              )}

              <div className="relative inline-flex flex-col items-center">
                {/* Step Number */}
                <span className="absolute -top-2 -right-2 text-5xl font-heading font-bold text-secondary/20">
                  {item.step}
                </span>
                
                {/* Icon */}
                <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-secondary to-secondary/80 flex items-center justify-center mb-6 shadow-glow">
                  <item.icon className="h-10 w-10 text-secondary-foreground" />
                </div>
              </div>

              <h3 className="text-2xl font-heading font-bold text-primary-foreground mb-3">
                {item.title}
              </h3>
              <p className="text-primary-foreground/70 max-w-xs mx-auto">
                {item.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
