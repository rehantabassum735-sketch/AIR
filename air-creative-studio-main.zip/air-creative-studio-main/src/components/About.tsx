import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { Sparkles, Users, Zap } from 'lucide-react';

const features = [
  {
    icon: Sparkles,
    title: 'Creative Excellence',
    description: 'Unique designs that capture your brand identity and engage your audience.',
  },
  {
    icon: Zap,
    title: 'Modern Technology',
    description: 'Built with cutting-edge tools for performance, security, and scalability.',
  },
  {
    icon: Users,
    title: 'Client-Focused',
    description: 'Your success is our priority. We listen, adapt, and deliver.',
  },
];

export const About = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="about" className="section-padding bg-background-secondary">
      <div className="section-container">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left Content */}
          <motion.div
            ref={ref}
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-block px-4 py-2 mb-4 text-sm font-medium text-primary bg-primary/10 rounded-full">
              About Us
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-heading font-bold text-foreground mb-6">
              We Build Digital
              <span className="text-secondary"> Experiences</span> That Matter
            </h2>
            <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
              AIR is a creative tech organization founded by{' '}
              <span className="font-semibold text-foreground">M. Rehan Tabassum</span>{' '}
              with a mission to help businesses thrive in the digital world. We combine
              creativity with technology to deliver websites and digital solutions that
              not only look stunning but also drive real results.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              From startups to established businesses, we partner with clients who share
              our passion for innovation and excellence. Every project is an opportunity
              to create something extraordinary together.
            </p>
          </motion.div>

          {/* Right Features */}
          <div className="space-y-6">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, x: 40 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="flex gap-5 p-6 bg-card rounded-xl shadow-card hover:shadow-card-hover transition-shadow duration-300"
              >
                <div className="flex-shrink-0 w-12 h-12 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                  <feature.icon className="h-6 w-6 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="text-lg font-heading font-semibold text-foreground mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
