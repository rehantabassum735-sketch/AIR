import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import { Check } from 'lucide-react';

const benefits = [
  {
    title: 'Modern Design',
    description: 'Cutting-edge aesthetics that set you apart from the competition.',
  },
  {
    title: 'Client-Focused Approach',
    description: 'Your vision and goals are at the heart of everything we do.',
  },
  {
    title: 'Fast Communication',
    description: 'Quick responses and regular updates throughout your project.',
  },
  {
    title: 'Custom Solutions',
    description: 'Tailored strategies designed specifically for your unique needs.',
  },
  {
    title: 'Quality Assurance',
    description: 'Rigorous testing ensures your project works flawlessly.',
  },
  {
    title: 'Ongoing Support',
    description: "We're here to help even after your project launches.",
  },
];

export const WhyChooseUs = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section className="section-padding bg-background">
      <div className="section-container">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left Content */}
          <motion.div
            ref={ref}
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-block px-4 py-2 mb-4 text-sm font-medium text-primary bg-primary/10 rounded-full">
              Why AIR
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-heading font-bold text-foreground mb-6">
              Why Choose <span className="text-secondary">AIR?</span>
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              We're more than just developers – we're your digital partners. Our team
              combines technical expertise with creative thinking to deliver solutions
              that truly make a difference for your business.
            </p>
          </motion.div>

          {/* Right Benefits Grid */}
          <div className="grid sm:grid-cols-2 gap-6">
            {benefits.map((benefit, index) => (
              <motion.div
                key={benefit.title}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: index * 0.08 }}
                className="flex gap-4"
              >
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-br from-secondary to-secondary/80 flex items-center justify-center">
                  <Check className="h-4 w-4 text-secondary-foreground" />
                </div>
                <div>
                  <h3 className="font-heading font-semibold text-foreground mb-1">
                    {benefit.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">{benefit.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
