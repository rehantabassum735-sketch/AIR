import { Facebook, Twitter, Instagram, Linkedin, Phone, Mail } from 'lucide-react';

const quickLinks = [
  { name: 'Home', href: '#home' },
  { name: 'About', href: '#about' },
  { name: 'Services', href: '#services' },
  { name: 'Projects', href: '#projects' },
  { name: 'Contact', href: '#contact' },
];

const socialLinks = [
  { icon: Facebook, href: '#', label: 'Facebook' },
  { icon: Twitter, href: '#', label: 'Twitter' },
  { icon: Instagram, href: '#', label: 'Instagram' },
  { icon: Linkedin, href: '#', label: 'LinkedIn' },
];

export const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="section-container py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="lg:col-span-2">
            <h2 className="text-3xl font-heading font-bold mb-4">AIR</h2>
            <p className="text-primary-foreground/70 mb-6 max-w-md leading-relaxed">
              We create stunning websites and smart digital solutions that help
              businesses thrive in the modern digital landscape. Let's build something
              amazing together.
            </p>
            <div className="flex gap-4">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  aria-label={social.label}
                  className="w-10 h-10 rounded-full bg-primary-foreground/10 flex items-center justify-center hover:bg-secondary transition-colors"
                >
                  <social.icon className="h-5 w-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-heading font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-primary-foreground/70 hover:text-secondary transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-heading font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-4">
              <li>
                <a
                  href="tel:+923186272110"
                  className="flex items-center gap-3 text-primary-foreground/70 hover:text-secondary transition-colors"
                >
                  <Phone className="h-5 w-5" />
                  <span>+92 318 6272110</span>
                </a>
              </li>
              <li>
                <a
                  href="mailto:rehantabassum735@gmail.com"
                  className="flex items-center gap-3 text-primary-foreground/70 hover:text-secondary transition-colors"
                >
                  <Mail className="h-5 w-5" />
                  <span>rehantabassum735@gmail.com</span>
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-primary-foreground/10">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-sm text-primary-foreground/60">
              © {currentYear} AIR. All rights reserved.
            </p>
            <p className="text-sm text-primary-foreground/60">
              Founded by M. Rehan Tabassum
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};
