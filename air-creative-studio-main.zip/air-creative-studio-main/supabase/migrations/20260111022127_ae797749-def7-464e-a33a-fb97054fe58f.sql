-- Create ratings table
CREATE TABLE public.ratings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  name TEXT NOT NULL,
  email TEXT,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  review TEXT,
  is_approved BOOLEAN NOT NULL DEFAULT false
);

-- Enable Row Level Security
ALTER TABLE public.ratings ENABLE ROW LEVEL SECURITY;

-- Allow anyone to submit a rating
CREATE POLICY "Anyone can submit rating"
ON public.ratings
FOR INSERT
WITH CHECK (true);

-- Allow anyone to view approved ratings
CREATE POLICY "Anyone can view approved ratings"
ON public.ratings
FOR SELECT
USING (is_approved = true);